﻿using Photon.Pun;
using System;
using System.Collections.Generic;
using System.Text;

namespace Quantum_Temp.Menu
{
    class mods
    {
        public static void Disconnect()
        {
            PhotonNetwork.Disconnect();
        }
    }
}
